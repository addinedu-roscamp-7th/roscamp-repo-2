#!/bin/bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="$BASE_DIR/lib:$LD_LIBRARY_PATH"
exec "$BASE_DIR/information_desk"
